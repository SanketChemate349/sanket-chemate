The program written is to display an image slider in the user’s browser which can manual as well as automatic. The types of files that were used to make this program are HTML, CSS and JS. The roles these programs played in this project are explained as follows: 
 
 
 HTML: 
The codes written in HTML are used for naming the Heading and for the buttons in the browser, and to display the output of the codes written in JavaScript. Without the HTML document it would be impossible to display it since it is an electronic document of sorts.  
 
 
 CSS: 
Cascading Style Sheets is used to add elements in pages to make it seem more visually appealing and good looking. In this project, CSS is used to add colors, change fonts, and add transition to image and the name box while hitting next button. 
 
 
 JavaScript: 
The codes that were written in JavaScript are used for the buttons to change slide in the user’s browser it also has an auto slide function which triggers after every 5sec. 
